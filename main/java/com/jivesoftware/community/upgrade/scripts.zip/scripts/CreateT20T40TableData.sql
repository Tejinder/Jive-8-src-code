INSERT INTO grailT20T40MetaFields(tid, "name") VALUES (1,'T20');
INSERT INTO grailT20T40MetaFields(tid, "name") VALUES (2,'T40');
INSERT INTO grailT20T40MetaFields(tid, "name") VALUES (3,'Non-T40');
