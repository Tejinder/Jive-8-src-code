INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 1);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 2);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 3);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 4);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 5);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 6);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 7);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 8);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 9);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 10);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 11);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 12);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 13);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 14);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 15);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 16);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 17);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 18);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 19);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 20);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 21);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 22);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 23);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 24);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 25);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 26);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 27);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 28);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (1, 29);

INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (2, 14);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (2, 17);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (2, 18);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (2, 19);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (2, 22);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (2, 26);


INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (3, 14);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (3, 16);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (3, 17);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (3, 18);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (3, 19);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (3, 26);

INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (4, 7);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (4, 17);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (4, 18);

INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (5, 17);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (5, 18);

INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (6, 12);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (6, 17);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (6, 18);

INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (7, 7);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (7, 17);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (7, 18);

INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (8, 17);
INSERT INTO grailpbfieldmappingfields (productid, brandid) VALUES (8, 18);