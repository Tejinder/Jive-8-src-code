CREATE TABLE grailmethodologygroupfields
(
  id bigint NOT NULL,
  name character varying(255) NOT NULL
)

INSERT INTO grailmethodologygroupfields(id, "name") VALUES (1,'Brand - NPI');
INSERT INTO grailmethodologygroupfields(id, "name") VALUES (2,'Brand - Other');
INSERT INTO grailmethodologygroupfields(id, "name") VALUES (3,'Illicit Trade');
INSERT INTO grailmethodologygroupfields(id, "name") VALUES (4,'Others');
INSERT INTO grailmethodologygroupfields(id, "name") VALUES (5,'Pricing');
INSERT INTO grailmethodologygroupfields(id, "name") VALUES (6,'Product');
INSERT INTO grailmethodologygroupfields(id, "name") VALUES (7,'Retail Audit');
INSERT INTO grailmethodologygroupfields(id, "name") VALUES (8,'Segmentation');
INSERT INTO grailmethodologygroupfields(id, "name") VALUES (9,'Trade');
INSERT INTO grailmethodologygroupfields(id, "name") VALUES (10,'Tracking');
