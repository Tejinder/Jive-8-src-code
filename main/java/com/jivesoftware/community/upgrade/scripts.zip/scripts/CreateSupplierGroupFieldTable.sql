INSERT INTO grailSupplierGroupFields(id, "name") VALUES (0, '');
INSERT INTO grailSupplierGroupFields(id, "name") VALUES (1, 'Unknown');
INSERT INTO grailSupplierGroupFields(id, "name") VALUES (2, 'Kantar Group');
INSERT INTO grailSupplierGroupFields(id, "name") VALUES (3, 'GfK Group');
INSERT INTO grailSupplierGroupFields(id, "name") VALUES (4, 'Ipsos');
INSERT INTO grailSupplierGroupFields(id, "name") VALUES (5, 'MASMI');
INSERT INTO grailSupplierGroupFields(id, "name") VALUES (6, 'Nielsen');
INSERT INTO grailSupplierGroupFields(id, "name") VALUES (7, 'Synovate');