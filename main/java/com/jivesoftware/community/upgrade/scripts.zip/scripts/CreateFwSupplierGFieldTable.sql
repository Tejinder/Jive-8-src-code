INSERT INTO grailFwSupplierGFields(id, "name") VALUES (0, '');
INSERT INTO grailFwSupplierGFields(id, "name") VALUES (1, 'Unknown');
INSERT INTO grailFwSupplierGFields(id, "name") VALUES (2, 'Kantar Group');
INSERT INTO grailFwSupplierGFields(id, "name") VALUES (3, 'GfK Group');
INSERT INTO grailFwSupplierGFields(id, "name") VALUES (4, 'Ipsos');
INSERT INTO grailFwSupplierGFields(id, "name") VALUES (5, 'MASMI');
INSERT INTO grailFwSupplierGFields(id, "name") VALUES (6, 'Nielsen');
INSERT INTO grailFwSupplierGFields(id, "name") VALUES (7, 'Synovate');