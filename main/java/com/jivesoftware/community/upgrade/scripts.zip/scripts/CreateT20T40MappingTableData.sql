INSERT INTO grailT20T40MappingMetaFields(tid, eid) VALUES (1, 1);
